package user;


public class UserDTO {
//	DATA Transfer object
	String userID;
	String userPW;
	String userPN;
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserPW() {
		return userPW;
	}
	public void setUserPW(String userPW) {
		this.userPW = userPW;
	}
	public String getUserPN() {
		return userPN;
	}
	public void setUserPN(String userPN) {
		this.userPN = userPN;
	}
	
	
}
